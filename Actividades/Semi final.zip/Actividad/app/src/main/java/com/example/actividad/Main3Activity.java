package com.example.actividad;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;

public class Main3Activity extends AppCompatActivity {
    TextView edsesion;
    Spinner listSp;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);
        edsesion= findViewById(R.id.etDescription);
        listSp=findViewById(R.id.spAnimals);
        ArrayAdapter<CharSequence> adapter=ArrayAdapter.createFromResource(this,R.array.animal,android.R.layout.simple_spinner_item);
        listSp.setAdapter(adapter);
        listSp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                edsesion.setText(adapterView.getItemAtPosition(i).toString());
            }
            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
            }
        });

    }
}
