package com.example.actividad;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.ListView;

public class Lista_Gestion_Agenda extends AppCompatActivity {
    String nombre, docu;

    //Arreglo crea los elementos de la lista
    private String gestionAgenda[]=new String[]{"Agenda académica","Tablero virtual"};

    //Arreglo Asigna imagenes a la lista
    private Integer[] imgid={
            R.drawable.img,
            R.drawable.wap };

    private ListView lista;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.lista__gestion__agenda);

        //Implementa logo App en la barra de acción
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        Intent intent=getIntent();
        docu=intent.getStringExtra("docu");
        nombre=intent.getStringExtra("nombre");

        AdministradorListAdapter adapter=new AdministradorListAdapter(this,gestionAgenda,imgid);
        lista=findViewById(R.id.mi_lista);

    }


}